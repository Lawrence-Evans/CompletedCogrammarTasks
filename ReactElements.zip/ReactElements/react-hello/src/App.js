// import logo from './logo.svg';
import "./App.css";

const user = {
  name: "Jean",
  surname: "Connor",
  date_of_birth: "24/07/1982",
  address: "14B Forest Court",
  country: "Canada",
  email: "JC@yahoo.com",
  telephone: "+1 613-957-2991",
  company: "Media Res",
  profile_picture:
    "https://images.unsplash.com/photo-1543269664-76bc3997d9ea?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  shopping_cart: [
    "Rich Tea Biscuits",
    "Lavazza Coffee",
    "Kitchen Towels",
    "Football",
    "A4 Envelopes",
  ],
};

function App() {
  return (
    <div>
      <header id="top">
        <h3><span>Shopper Account for:</span></h3>
      </header>
      <div id="accountName">
        <h1><span>{user.name + " " + user.surname}</span></h1>
        <img
          id="profilePicture"
          alt="Account profile"
          src={user.profile_picture}
        ></img>
      </div>
      <div id="details">
        <h2>Details</h2>
        {/* Use CSS classname to allow "\n" to create new line for each specific property*/}
        <div className="linebreak">
          {/* Added bold inline styling to help identify details and quicker to do than from the CSS with extra tags */}
          <b>DOB:</b> {user.date_of_birth +
            "\n"}
            <b>Country:</b> {user.country +
            "\n"}
            <b>Email:</b> {user.email +
            "\n"}
            <b>Tele.:</b> {user.telephone +
            "\n"}
            <b>Company:</b> {user.company}
        </div>
      </div>
      <div id="shoppingList">
        <h2>Shopping List</h2>
        <ul>
          {/* With a single array it can mapped with each variable to its own li which also lots it on a new line. */}
          {user.shopping_cart.map((i) => {
            return <li>{i}</li>;
          })}
        </ul>
      </div>
      <footer id="bottom">
        <p><span>Shopper browser incorparated©</span></p>
      </footer>
    </div>
  );
}

export default App;
