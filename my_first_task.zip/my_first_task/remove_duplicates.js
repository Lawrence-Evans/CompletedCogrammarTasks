// Custom command added to package "rdup" to run this code in cli.
// Installed lodash library locally and required its array functions.
const lodash = require("lodash/array");

let duplicateNumbers = [
  1, 2, 10, 100, 10, 2, 5, 6, 10, 1000, 7, 2, 100, 1, 5, 7, 10,
];

// Logging array with duplicates to compare before and after of the lodash.uniq function.
console.log(duplicateNumbers);

// Used lodash uniq which creates a duplicate-free version of an array, using SameValueZero
// for equality comparisons, in which only the first occurrence of each element is kept.
numbers = lodash.uniq(duplicateNumbers);

console.log(numbers);