const lodash = require('lodash/array');

let duplicateNumbers = [1, 2, 10, 100, 10, 2, 5, 6, 10, 1000, 7, 2, 100, 1, 5, 7, 10];

console.log(duplicateNumbers);

numbers = lodash.uniq(duplicateNumbers);

console.log(numbers);