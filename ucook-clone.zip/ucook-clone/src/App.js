import Stack from "react-bootstrap/Stack";
import Nav from "react-bootstrap/Nav";
// Import of react components from local folder. Unsure if its possible to consildate these into a single import line.
import NavDropdownButton from "./components/navDropdownButton.jsx";
import MealCarousel from "./components/carousel.jsx";
import SignUpButton from "./components/button.jsx";
import EmailInput from "./components/emailInput.jsx";

// Partial clone of https://www.ucook.co.za/
// See NavDropdownButton fuction inside Nav for prop passing.

function App() {
  return (
    <div className="App">
      <div class="nav-flex-container">
        <Nav>
          <Nav.Item>
            <Nav.Link href="https://www.ucook.co.za/">
              <img src="./logo.svg" alt="logo" />
            </Nav.Link>
          </Nav.Item>
          {/* Imported dropdown for meal kits, wine and about ucook */}
          <NavDropdownButton name="Meal Kits" />
          <Nav.Item>
            <Nav.Link eventKey="link-3">Wine</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Market</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Weekend Boxes</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">About Ucook</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Partner with us</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Gift Cards</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Wine</Nav.Link>
          </Nav.Item>
        </Nav>
        <Nav>
          <Nav.Item>
            <Nav.Link eventKey="link-1">Login</Nav.Link>
          </Nav.Item>
          <SignUpButton />
          <Nav.Item>
            <Nav.Link eventKey="link-3">Basket</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="link-3">Counter</Nav.Link>
          </Nav.Item>
        </Nav>
      </div>
      {/* Used stack to orient and space each part of page */}
      <Stack gap={1}>
        <div id="Stack1" className="">
          <div id="gridAcross2">
            <div>
              <h1 class="padding">Dinner, made easy</h1>
              <h4 class="padding">Fresh ingredients from the farm</h4>
              <div class="padding">
                We deliver easy to follow and delicious recipes, and perfectly
                pre-portioned fresh ingredients to your door every week.
              </div>
              <div class="padding">
                <SignUpButton />
              </div>
            </div>
            <div>
              <img id="image" src="./image1.webp" alt="product" />
            </div>
          </div>
        </div>
        <div id="Stack2" className="">
          <h3 class="justify-content-center">How does it work?</h3>
          <div>
            <div id="gridAcross3">
              <div>
                <img id="svg" src="./svg1.svg" alt="product" />
                <h4>1. You choose</h4>
                <p>
                  Sign up, pick from 24 new dinner recipes every week and
                  explore our range of lunch, wine, market, and frozen craft
                  meals. Orders close 9am Wed - pause at any time!
                </p>
              </div>
              <div>
                <img id="svg" src="./svg2.svg" alt="product" />
                <h4>2. We deliver</h4>
                <p>
                  Get a weekly delivery of top quality, perfectly-portioned
                  fresh produce, shipped in an insulated cold box, straight to
                  your door.{" "}
                </p>
              </div>
              <div>
                <img id="svg" src="./svg3.svg" alt="product" />
                <h4>3. You cook</h4>
                <p>
                  Get simple-to-follow recipes and create restaurant quality
                  dishes in your own home with no more meal planning or food
                  waste.{" "}
                </p>
              </div>
            </div>
            <div class="justify-content-center">
              Got more Questions? - check out our FAQ's
            </div>
          </div>
        </div>
        <div id="Stack3" className="">
          <h3 class="justify-content-center">On the menu this week</h3>
          <div id="gridAcross6">
            <div>Adventurous Foodie</div>
            <div>Quick & Easy</div>
            <div>Carb Conscious</div>
            <div>Fan Faves</div>
            <div>Veggie</div>
            <div>Simple & Save</div>
          </div>
          <div class="justify-content-center">
            {/* Carosel for meal kits, wine and about ucook */}
            <MealCarousel />
          </div>
        </div>
        <div id="Stack4" class="justify-content-center">
          <div>KEEP IN TOUCH WITH OUR KITCHEN</div>
          <EmailInput />
          <SignUpButton />
        </div>
        <div id="Stack5" class="justify-content-center">
          <div class="padding">PRODUCT</div>
          <div class="padding">COMPANY</div>
          <div class="padding">SUPPORT</div>
          <div>
            <img id="appLogos" src="./appLogos.gif" alt="app Logos" />
          </div>
        </div>
        <div id="Stack6">
          <div>
            UCOOK. All rights reserved by The Supper Society Proprietary Limited
            | Liquor License: WCP/042073 | GAU/10615
          </div>
          <div>Terms & Conditions Privacy Policy Referral Terms</div>
        </div>
      </Stack>
    </div>
  );
}

export default App;
