import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';

// Takes the name props to create a dropdown. NOTE Haven't got worked out how to do the same with NavDropdown
function NavDropdownExample({name, itemName1, itemName2, itemName3}) {
  const handleSelect = (eventKey) => alert(`selected ${eventKey}`);
  return (
    <Nav activeKey="1" onSelect={handleSelect}>
      <NavDropdown title={name} id="nav-dropdown">
            <NavDropdown.Item title={itemName1} eventKey="1">Meal Kit Menu</NavDropdown.Item>
            <NavDropdown.Item title={itemName2} eventKey="2">Plans & Pricing</NavDropdown.Item>
            <NavDropdown.Item title={itemName3} eventKey="3">Our Suppliers</NavDropdown.Item>
          </NavDropdown>
    </Nav>
  );
}

export default NavDropdownExample;