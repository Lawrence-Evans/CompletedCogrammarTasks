import React from 'react';
import ReactDOM from 'react-dom/client';
// Styling imports
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import App from './App';

// Partial clone of https://www.ucook.co.za/

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

