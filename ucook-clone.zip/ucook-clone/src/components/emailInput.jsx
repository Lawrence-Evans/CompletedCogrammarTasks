import Form from "react-bootstrap/Form";

function EmailInput() {
  return (
    <>
      <Form.Control
        type="email"
        id="emailSignUp"
        placeholder="Enter your email"
      />
    </>
  );
}

export default EmailInput;
