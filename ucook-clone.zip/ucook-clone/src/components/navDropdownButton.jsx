import Nav from "react-bootstrap/Nav";
import NavDropdown from "react-bootstrap/NavDropdown";

// Takes the name prop and array prop to create a dropdown. Eventkey 1 is styled with a blue background from react css.
// NOTE couldn't identify a way to pass the NavDropdown.Items and make this component reuseable for any dropdown button.
// Or create a separate NavDropdown.Item component that could then me passed their own name props.
//
function NavDropdownButton({ name }) {
  const handleSelect = (eventKey) => alert(`selected ${eventKey}`);
  return (
    <Nav activeKey="1" onSelect={handleSelect}>
      <NavDropdown title={name} id="nav-dropdown">
        <NavDropdown.Item eventKey="1">Meal Kit Menu</NavDropdown.Item>
        <NavDropdown.Item eventKey="2">Plans & Pricing</NavDropdown.Item>
        <NavDropdown.Item eventKey="3">Our Suppliers</NavDropdown.Item>
      </NavDropdown>
    </Nav>
  );
}

export default NavDropdownButton;
