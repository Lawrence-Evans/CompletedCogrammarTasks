import Button from "react-bootstrap/Button";

function SignUpButton() {
  return (
    <>
      <Button variant="success">Sign Up</Button>{" "}
    </>
  );
}

export default SignUpButton;
