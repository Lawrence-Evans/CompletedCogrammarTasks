import Carousel from "react-bootstrap/Carousel";

// Image and name of each meal linked or typed for automatic single image carousel.

function MealCarousel() {
  return (
    <Carousel>
      <Carousel.Item>
        <img id="meal" src="meal1.webp" alt="product" />
        <Carousel.Caption>
          <h3>Succulent Ostrich & Whiskey Source</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img id="meal" src="meal2.webp" alt="product" />
        <Carousel.Caption>
          <h3>Settyn's Hake Goujons & Avo Tartar</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img id="meal" src="meal3.webp" alt="product" />
        <Carousel.Caption>
          <h3>Sumptuous Sirloin & Rustic Mash</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img id="meal" src="meal4.webp" alt="product" />
        <Carousel.Caption>
          <h3>Stettyn's Vegetarian Bang-Bang Cauli</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img id="meal" src="meal5.webp" alt="product" />
        <Carousel.Caption>
          <h3>Vegetarian Tomato Soup</h3>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default MealCarousel;
