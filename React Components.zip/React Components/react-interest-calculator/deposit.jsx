import React from "react";

export function DepositComponent(props) {
    
    return (
        <form id="deposit" onSubmit={handleDeposit}>
        <label>
          Deposit: £
          {/* Step to limit input to 2 decimal places min=0 to prevent negative numbers */}
          <input
            type="number"
            step="0.01"
            name="balance"
            min="0"
            placeholder="0.00"
          />
        </label>
        <button type="submit">Deposit</button>
      </form>
    );
  }

export default HandleDeposit