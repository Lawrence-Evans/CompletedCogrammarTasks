import React from "react";
import { useState } from "react";

export default function DisplayBalance() {
  // Create the name state variable
  const [balance, setBalance] = useState(0);
  // Create a const to handle the state change
  const handleSubmit = (e) => {
    e.preventDefault();
    setBalance(balance + parseFloat(e.target.balance.value));
  };
  return (
    <div>
      <h3> Balance : {balance}</h3>
      <form onSubmit={handleSubmit}>
        <label>
          Enter Name :
          <input
            // value={balance}
            type="number"
            step="0.01"
            min="0"
            placeholder="0.00"
            onChange={(e) => setBalance(e.target.value)}
          />
        </label>
        <button type="submit">Deposit</button>
      </form>
    </div>
  );
}
