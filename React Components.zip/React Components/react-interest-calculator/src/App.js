import "./App.css";
import { useState } from "react";
import React from "react";
import DisplayBalance from "./components/displayBalance";

// Uses multiple event a handlers and form submissions to increase and decrease the Balance variable.
export function Balance() {
  const [balance, setBalance] = useState(0);
  // Alert if balance is negative and in the red so to speak. Can't use =, >, < operators, negative values in this
  // conditional statement or the "else" conditional. Has to be "else if" or two separate if statements. Otherwise there
  // is a TypeError: document.getElementById(...) is null. Is this because the page elements have not been fully
  // created when the function runs? If so why do < and > still work?
  if (balance < 0) {
    document.getElementById("app").style.backgroundColor = "red";
    alert("! Balance overdrawn !");
  } else if (balance > 0) {
    document.getElementById("app").style.backgroundColor = "skyblue";
  };
  // parseInt to make number an float
  // preventDefault to stop form submission and page reload
  const handleDeposit = (e) => {
    e.preventDefault();
    setBalance(balance + parseFloat(e.target.balance.value));
  };
  const handleWithdraw = (e) => {
    e.preventDefault();
    setBalance(balance - parseFloat(e.target.balance.value));
  };
  // e.target.balance.value is divided by 100 so percent can be input as eg 1-100% instead of 0.01 to 1.
  const handleInterest = (e) => {
    e.preventDefault();
    setBalance(balance + balance * parseFloat(e.target.balance.value / 100));
  };
  const handleInterestFixed = (e) => {
    e.preventDefault();
    setBalance(balance + balance * 0.035);
  };
  const handleFeesPercent = (e) => {
    e.preventDefault();
    setBalance(balance - balance * parseFloat(e.target.balance.value / 100));
  };
  return (
    <div id="app">
      {/* Trying to pass props to components involving form submission */}
      <DisplayBalance />
      <h1 id="balance">Balance : £{balance} </h1>
      <div id="grid2across">
        <form id="deposit" onSubmit={handleDeposit}>
          <label>
            Deposit: £
            {/* Step to limit input to 2 decimal places min=0 to prevent negative numbers */}
            <input
              type="number"
              step="0.01"
              name="balance"
              min="0"
              placeholder="0.00"
            />
          </label>
          <button type="submit">Deposit</button>
        </form>
        <form id="withdraw" onSubmit={handleWithdraw}>
          <label>
            Withdraw: £
            <input
              type="number"
              step="0.01"
              name="balance"
              min="0"
              placeholder="0.00"
            />
          </label>
          <button type="submit">Withdraw</button>
        </form>
        <div id="interest">
          <form onSubmit={handleInterestFixed}>
            <label>
              Interest Fixed 3.5%:
              {/* <input type="number" step="0.01" name="balance" min="0" placeholder="0%"/> */}
            </label>
            <button type="submit">Add Interest</button>
          </form>
          <form onSubmit={handleInterest}>
            <label>
              Interest:
              <input
                type="number"
                step="0.01"
                name="balance"
                min="0"
                placeholder="0%"
              />
            </label>
            <button type="submit">Add Interest</button>
          </form>
        </div>
        {/* Reused handleWithdraw re skinned as charge fee in £ as it has the same required effect. */}
        <div id="fees">
          <form onSubmit={handleWithdraw}>
            <label>
              Charge £ fee:
              <input
                type="number"
                step="0.01"
                name="balance"
                min="0"
                placeholder="0.00"
              />
            </label>
            <button type="submit">Charge £ fee</button>
          </form>
          <form onSubmit={handleFeesPercent}>
            <label>
              Charge % fee:
              <input
                type="number"
                step="0.01"
                name="balance"
                min="0"
                placeholder="0%"
              />
            </label>
            <button type="submit">Charge % fee</button>
          </form>
        </div>
      </div>
    </div>
  );
}

// Function that returns the app webpage render.
function App() {
  return (
    <div>
      <header></header>
      <div>
        <Balance />
      </div>
      <br></br>
    </div>
  );
}

export default App;
